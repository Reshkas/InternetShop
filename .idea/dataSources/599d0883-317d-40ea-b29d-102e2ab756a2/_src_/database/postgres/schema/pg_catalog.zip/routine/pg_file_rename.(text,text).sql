create function pg_catalog.pg_file_rename(text, text) returns boolean
LANGUAGE SQL
AS $$
SELECT pg_catalog.pg_file_rename($1, $2, NULL::pg_catalog.text);
$$;
