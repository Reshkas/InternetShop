create function pg_catalog.textanycat(text, anynonarray) returns text
LANGUAGE SQL
AS $$
select $1 || $2::pg_catalog.text
$$;
